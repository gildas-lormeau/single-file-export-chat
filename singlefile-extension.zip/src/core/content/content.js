if (location.hash.includes("conversations/General")) {
    exportConversation();
} else if (location.hash.includes("conversations")) {
    exportChat();
}